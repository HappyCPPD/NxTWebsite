# RULES

- Category: MISC / BABY
- Author: hofill
- Status: Solved
- Current value when solved: 128 points

## Solution

Open the site rules page and read the flag-format section. It includes the
example flag used by the challenge:

```text
TFCCTF{M4ny_ch4ng3s...m0r3_3ff0rt}
```

After visiting the rules page, the challenge dashboard showed `RULES` as
`SOLVED`. The account total increased from 229 points / 1 flag to 357 points /
2 flags.

## Rules summary

- Flags normally use `TFCCTF{anything_goes_here}`.
- The Open division permits unrestricted AI use.
- The Classic division permits only very light AI assistance, not delegating
  challenge-solving work.
- Both divisions share the overall prize scoreboard; division boards are for
  comparison within each division.
