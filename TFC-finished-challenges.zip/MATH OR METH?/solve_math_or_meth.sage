from zipfile import ZipFile
with ZipFile('MATH OR METH?/chall.zip') as zf:
    exec(zf.read('output.py'))

# L = {v in Z^m : <h,v> = 0 (mod p)}.
# Its exceptionally short vectors are integer null-vectors of every hidden row.
inv = inverse_mod(h[0], p)
rows = [[p] + [0] * (m - 1)]
for j in range(1, m):
    v = [0] * m
    v[0] = ZZ((-h[j] * inv) % p)
    if v[0] > p // 2:
        v[0] -= p
    v[j] = 1
    rows.append(v)

K = Matrix(ZZ, rows).LLL(delta=0.999)
short = [v for v in K.rows() if v.norm() < 10000]
print('short modular relations:', len(short), [round(float(v.norm()), 2) for v in short[:35]])

# Thirty-one independent short relations are expected (m-n = 31).
Y = Matrix(ZZ, short).row_space().basis_matrix()
print('relation rank:', Y.rank())

# Recover the integer lattice orthogonal to those relations, i.e. the hidden row lattice.
R = Y.right_kernel_matrix().LLL(delta=0.999)
print('row lattice:', R.nrows(), R.ncols())

def decode(v):
    if min(v) < 0 or max(v) > B:
        return None
    x = sum(ZZ(v[i]) * ZZ(B + 1)^i for i in range(m))
    try:
        return int(x).to_bytes((int(x).bit_length() + 7) // 8, 'big')
    except Exception:
        return None

# Search short basis vectors and modest pairwise combinations/signs.
candidates = list(R.rows())
for i in range(R.nrows()):
    for j in range(i):
        candidates += [R[i] + R[j], R[i] - R[j], -R[i] + R[j], -R[i] - R[j]]

seen = set()
for v in candidates:
    for w in (v, -v):
        msg = decode(w)
        if msg and msg not in seen:
            seen.add(msg)
            if b'TFCCTF{' in msg or all(32 <= c < 127 for c in msg):
                print('CANDIDATE', msg)
